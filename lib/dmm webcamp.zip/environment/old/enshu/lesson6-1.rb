puts "計算をはじめます"
puts "何回繰り返しますか？"
repeat = gets.to_i
input_key_2 = gets.to_i
puts "計算結果を出力します"
puts "#{input_key_1}*#{input_key_2}=#{input_key_1 * input_key_2}"
puts "計算を終了します"