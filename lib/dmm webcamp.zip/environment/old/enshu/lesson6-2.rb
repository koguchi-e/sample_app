puts "計算をはじめます"
puts "何回繰り返しますか？"
repeat = gets.to_i
time = 1

while time <= repeat do
    puts "#{time}回目の計算"
    puts "2つの値を入力してください"
    a = gets.to_i
    b = gets.to_i
    puts "a=#{a}"
    puts "b=#{b}"
    puts "計算結果を出力します"
    puts "#{a} + #{b} = #{a +b}"
    puts "#{a} - #{b} = #{a -b}"
    puts "#{a} * #{b} = #{a *b}"
    puts "#{a} / #{b} = #{a /b}"
    time += 1
end
puts "計算を終了します"