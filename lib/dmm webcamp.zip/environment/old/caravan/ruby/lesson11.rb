class Car
    def run(distance)
        puts "車で#{distance}キロ走ります。"
    end
end

class Truck < Car
    def run
        supar 
        puts "大きな荷物を載せて走ります。"
    end
end

instance1 = Truck.new
instance1.run(5)