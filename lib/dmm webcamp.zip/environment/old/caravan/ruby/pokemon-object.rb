enemy = "ノーマル"
puts "#{enemy}タイプの敵が現れた！"

class Pikachu 
    def attack(lv, enemy)
        if enemy == "水"
            puts "攻撃力：#{lv * 20}"
        elsif enemy == "地面"
            puts "攻撃力：#{lv * 5}"
        else
            puts "攻撃力：#{lv * 10}"
        end
    end
end

pika = Pikachu.new
pika.attack(5,enemy)