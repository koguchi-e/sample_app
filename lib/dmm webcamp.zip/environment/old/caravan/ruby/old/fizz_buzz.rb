# 先に定義
def fizz_buzz(a)
    if (a % 3 == 0) && (a % 5 == 0)
        return "fizz_buzz"
    elsif a % 3 == 0
        return "Fizz"
    elsif a % 5 == 0
        return "Buzz"
    else 
        return a
    end
end

puts "数字を入力してください。"

a = gets.to_i

puts "結果は..."
puts fizz_buzz(a)
